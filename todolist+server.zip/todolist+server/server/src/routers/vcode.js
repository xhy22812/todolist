const express = require('express');
const Router = express.Router();
const svgCaptcha = require('svg-captcha');

const {formatData} = require('../utils');

Router

// /api/vcode/image
.get('/image',(req,res)=>{
    let options = {
        // size:6,
        ignoreChars: '0o1i',
        width: 100, // width of captcha
        height: 50, // height of captcha
        fontSize: 60 // captcha text size
    }
    var captcha = svgCaptcha.create(options);// {data,text}

    // Session 临时存储数据
    // 把验证码存在session,以便进行后期校验
    req.session.vcode = captcha.text.toLowerCase()

    console.log('image:',req.session.vcode)
    
    // res.type('svg');
    res.send(captcha.data);
})

// 校验验证码是否正确
.get('/check',async (req,res)=>{
    let {vcode} = req.query;
    if(vcode == req.session.vcode){
        
        res.send(formatData())
    }else{
        res.send(formatData({status:401}))
    }
})


module.exports = Router;