const express = require('express');
// 利用express的中间件Router
const Router = express.Router();
const cookieParser = require('cookie-parser')

// 路由中间件
const userRouter = require('./user');
const todoRouter = require('./todo');
const vcodeRouter = require('./vcode');

// 过滤器中间件
const {cors,session} = require('../filter');

// 格式化传入的参数
Router.use(express.json(),express.urlencoded({ extended: false }),cookieParser());

// 跨域设置
Router.use(cors);

// 会话识别
Router.use(session)

// 配置路由信息
// /api/user
Router.use('/user',userRouter);
Router.use('/todo',todoRouter);
Router.use('/vcode',vcodeRouter);

module.exports = Router;
