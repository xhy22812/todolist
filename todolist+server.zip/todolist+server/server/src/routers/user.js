const express = require('express');
const Router = express.Router();

const db = require('../db');
// 注册
// 前端进入/api/user/reg这个接口，就会进入这里面来
Router.post('/reg',async (req,res)=>{
    let {username,password,message} = req.body;
    // 查找数据库中是否存在相同的用户名
    let isusername=await db.find('user',{'username':username});
    // 判断
    if(!isusername.length){
        // 写入数据库
        let data = await db.create('user',{username,password,message,regtime:new Date()});
        res.send({status:200,msg:'success',data:isusername})
    }else{
        res.send({status:400,msg:'error',data:isusername})
    }
})

// 登录
// 前端进入/api/user/log这个接口，就会进入这里面来
Router.post('/log',async (req,res)=>{
    let {username,password} = req.body;
    // 查找数据库中是否存在相同的用户名
    let isusername=await db.find('user',{'username':username});
    // 判断
    if(isusername.length){
        res.send({status:200,msg:'success',data:isusername})
    }else{
        res.send({status:400,msg:'error',data:isusername})
    }
})

// 个人中心
// 前端进入/api/user/cen这个接口，就会进入这里面来
Router.post('/cen',async (req,res)=>{
    // console.log(req.body);
    let userid =req.body.userid;
    // 查找数据库中是否存在相同的用户id
    let isuserid=await db.find('user',{'_id':userid});
    // 判断
    if(isuserid.length){
        res.send({status:200,msg:'success',data:isuserid})
    }else{
        res.send({status:400,msg:'error',data:isuserid})
    }
})


// // 引入加密模块
// const crypto = require('crypto');


// const db = require('../db');
// const {formatData,token,formatParams,formatPassword} = require('../utils');


// const colName = 'user'

// const encryptoPassword = (password)=>{
//     const hash = crypto.createHash('md5');
//     hash.update(password);
//     password = hash.digest('base64');
//     return password;
// }

// Router.get('/',async (req,res)=>{
//     let { sort='regtime', page = 1, size = 5,  total = true } = req.query;
//     let skip = (page - 1) * size;
//     let limit = size * 1;
//     let query = formatParams(req.query,['fromuser'])
//     let result = await db.dispatch('find',colName,query,{sort,skip,limit,total,fields:{password:0}})
//     res.send(result);
// })

// // 注册/添加
// .post(['/','/reg'],async (req,res)=>{
//     let {username,password,vcode} = req.body; 
//     console.log('reg:',vcode,req.session.vcode)
//     if(vcode.toLowerCase() !== req.session.vcode){
//         res.send(formatData({status:400}));
//         return;
//     }

//     password = encryptoPassword(password);
//     let data = {
//         username,
//         password,
//         regtime : new Date()
//     }

//     let result
//     try{
//         await db.create(colName,data)
//         result = formatData();
//     }catch(err){
//         result = formatData({status:400})
//     }
//     res.send(result)
// })

// // 登录(生成token)
// .get('/login',async (req,res)=>{
//     let {username,password,vcode,remember} = req.query; 
//     console.log('login:',vcode,req.session.vcode)
//     if(vcode.toLowerCase() !== req.session.vcode){
//         res.send(formatData({status:400}));
//         return;
//     }

//     password = encryptoPassword(password);

//     let data = await db.find(colName,{username,password});
//     let result;
//     if(data.length>0){
//         // let {_id,mobile} = result.data[0];
//         if(remember){
//             let Authorization = token.create(username,'1d');
//             res.cookie('Authorization',Authorization);
//             data[0].Authorization = Authorization
//         }
//         result = formatData({data})
//     }else{
//         result = formatData({status:401})
//     }
//     res.send(result);
// })

// // 检测token是否过期
// .get('/verify',async (req,res)=>{
//     let {Authorization} = req.cookies;
//     let result = token.verify(Authorization);
//     if(result){
//         result = formatData()
//     }else{
//         result = formatData({status:401})
//     }
//     res.send(result);
// })

// 校验用户名是否被占用
// .get('/check',async (req,res)=>{
//     let {mobile} = req.query;

//     let result;
//     try{
//         let data = await db.find(colName,{mobile});
//         if(data.length>0){
//             result = formatData({status:400,msg:'user is exist'})
//         }else{

//             result = formatData()
//         }
//     }catch(err){
//         result = formatData({status:400,msg:err})
//     }
    
//     res.send(result);
// })

module.exports = Router;