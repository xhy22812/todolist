const express = require('express');
const Router = express.Router();

const db = require('../db');

// 添加数据
// 前端进入/api/todo/add这个接口，就会进入这里面来
Router.post('/add',async (req,res)=>{
    let {title,radio,rate,message,starttime,endtime,userid,state} = req.body;
    // 写入数据库
    let data = await db.create('todo',{userid,title,radio,rate,message,starttime,endtime,state,regtime:new Date()});
})

// 查找该用户id的数据
// 前端进入/api/todo/find这个接口，就会进入这里面来
Router.post('/find',async (req,res)=>{
    // 查找数据库中存在的用户id
    let userid =req.body.userid;
    let isuserid=await db.find('todo',{'userid':userid});
        res.send({status:200,msg:'success',data:isuserid})
})

// 查找数据id的数据
// 前端进入/api/todo/data这个接口，就会进入这里面来
Router.post('/data',async (req,res)=>{
    // 查找数据库中存在的用户id
    let dataid = req.body.id;
    let data=await db.find('todo',{'_id':dataid});
    res.send({status:200,msg:'success',data})
})

// 删除数据
// 前端进入/api/todo/del这个接口，就会进入这里面来
Router.post('/del',async (req,res)=>{
    // 查找数据库中存在的用户id
    let todoid = req.body.id;
    let istodoid=await db.find('todo',{'_id':todoid});
    // 判断
    if(istodoid.length){
        res.send({status:200,msg:'success'})
        let data = await db.delete('todo',{'_id':todoid},{safe:true});
    }else{
        res.send({status:400,msg:'error'})
    }
})

// 修改数据
// 前端进入/api/todo/update这个接口，就会进入这里面来
Router.post('/update',async (req,res)=>{
    // 查找数据库中存在的数据id并修改数据
    let data = await db.update('todo',{'_id':req.body.id},{$set:req.body});
})

// 修改state
// 前端进入/api/todo/updatestate这个接口，就会进入这里面来
Router.post('/updatestate',async (req,res)=>{
    let data = await db.update('todo',{'_id':req.body.id},{$set:{'state':!req.body.state}});
})

module.exports = Router;