module.exports = function(req, res, next) {
    let currentOrigin = req.get('Origin');
    res.set({
        "Access-Control-Allow-Origin":currentOrigin,
        "Access-Control-Allow-Headers":"Content-Type,Content-Length, Authorization, Accept,X-Requested-With,app",
        "Access-Control-Allow-Methods":"PUT,POST,GET,PATCH,DELETE,OPTIONS",
        "Access-Control-Allow-Credentials":true
    })

    // 跨域请求CORS中的预请求
    if(req.method=="OPTIONS") {
        res.sendStatus(200);/*让options请求快速返回*/
    } else{
        next();
    }
    
}