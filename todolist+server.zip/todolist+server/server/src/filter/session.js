const session = require('express-session');
module.exports = session({ 
    secret: 'laoxie', 
    // session.id有效期5分钟
    cookie: { maxAge:1000*60*5}
});