const cors = require('./cors');
const session = require('./session');

module.exports = {
    cors,
    session
}