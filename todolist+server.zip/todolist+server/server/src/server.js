const express = require('express');
const app = express();
const {PORT} = require('./config.json');
const rootRouter = require('./routers');


// 内置中间件：利用中间件实现静态资源服务器（加上__dirname，可在任意目录运行程序，如：npm start）
// app.use(express.static(path.join(__dirname,'./src')));

// 接口根路由
app.use('/api',rootRouter);


// history路由服务器配置
// app.use((req,res)=>{
//     let content  = fs.readFileSync(path.join(__dirname,'../public/index.html'));
//     res.set('Content-Type','text/html; charset=utf-8');
//     res.send(content)
// })

app.listen(PORT,()=>{
    console.log('server is running on port %s',PORT);
});