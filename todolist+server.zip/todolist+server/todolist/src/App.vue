<template>
  <div id="app">
    <Navbar  v-show="isNavbarShow"></Navbar>
    <!--路由容器 基于slot进行封装的  根据url路径显示不同的路由组件-->
    <router-view></router-view>
    <Tabbar v-show="isTabbarShow"></Tabbar>
  </div>
</template>

<script>
// 引入Navbar、Tabbar组件
import Navbar from "@/components/Navbar";
import Tabbar from "@/components/Tabbar";
import { mapState } from "vuex";
export default {
  components: {
    Navbar,
    Tabbar
  },
  computed: {
    ...mapState("tabbar", ["isTabbarShow"]),
    ...mapState("navbar", ["isNavbarShow"])
  }
};
</script>
<style lang="scss">
.app-enter-active {
  animation: move 0.5s;
}
.app-leave-active {
  animation: move 0.5s reverse;
}

@keyframes move {
  0% {
    opacity: 0;
    transform: translateY(50px);
  }
  100% {
    opacity: 1;
    transform: translateY(0px);
  }
}
</style>
