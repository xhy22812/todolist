import Vue from 'vue'
import Vuex from 'vuex'

import tabbar from "./module/tabbarmodule"
import navbar from "./module/navbarmodule"


Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    isTabbarShow: true,
    isNavbarShow: true,
  },
  mutations: {},
  actions: {},
  modules: {
    tabbar, // tabbar的模块
    navbar,

  }
})
