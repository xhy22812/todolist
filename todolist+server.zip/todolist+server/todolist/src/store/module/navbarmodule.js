// 选项卡vuex共享配置
const module = {
    namespaced: true,
    state:{
        isNavbarShow:true, 
    },
    mutations:{
        navbarshow(state){
            state.isNavbarShow = true
        },
        navbarhide(state){
            state.isNavbarShow = false
        }
    }
}

export default module