<template>
  <div class="content">
    <div class="unfinish">
      <van-checkbox v-model="unfinish" icon-size=".2rem" disabled>未完成</van-checkbox>
      <p v-show="dt.filter(obj=>{return obj.state==false})==''" class="remind">暂无需完成的待办事项</p>
      <div class="list" v-for="item in dt.filter(obj=>{return obj.state==false})" :key="item._id">
        <van-checkbox
          v-model="item.state"
          @click="checkTodo(item._id,item.state)"
          icon-size=".18rem"
        >{{item.title}}</van-checkbox>
        <van-tag plain>等级{{item.rate}}</van-tag>
        <span>{{item.endtime}}</span>
        <van-icon name="delete" size=".24rem" style="float:right" @click="deleteTodo(item._id)" />
        <van-icon
          name="edit"
          size=".24rem"
          style="float:right; margin-right:0.1rem"
          @click="editTodo(item._id)"
        />
      </div>
    </div>
    <div class="finish">
      <van-checkbox v-model="finish" icon-size=".2rem" disabled>已完成</van-checkbox>
      <p v-show="dt.filter(obj=>{return obj.state==true})==''" class="remind">暂无已完成的待办事项</p>
      <div class="list" v-for="item in dt.filter(obj=>{return obj.state==true})" :key="item._id">
        <van-checkbox
          v-model="item.state"
          @click="checkTodo(item._id,item.state)"
          icon-size=".18rem"
        >{{item.title}}</van-checkbox>
        <van-tag plain>等级{{item.rate}}</van-tag>
        <span>{{item.endtime}}</span>
        <van-icon name="delete" size=".24rem" style="float:right" @click="deleteTodo(item._id)" />
        <van-icon
          name="edit"
          size=".24rem"
          style="float:right;margin-right:0.1rem"
          @click="editTodo(item._id)"
        />
      </div>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import { instance } from "@/utils/http";
import { Checkbox, CheckboxGroup, Tag, Icon, Notify } from "vant";

Vue.use(Checkbox);
Vue.use(CheckboxGroup)
  .use(Tag)
  .use(Icon)
  .use(Notify);
export default {
  data() {
    return {
      dt: "",
      unfinish: false,
      finish: true,
    };
  },
  created() {
    this.renderUI();
  },
  methods: {
    renderUI() {
      // 发送请求到后端
      let userid = { userid: localStorage.getItem("todolistid") };
      instance.post("/api/todo/find", userid).then(res => {

          this.dt = res.data.data;
          console.log(this.dt);
      });
    },
    checkTodo(id, state) {
      console.log(state);

      instance.post("/api/todo/updatestate", { id, state }).then(res => {
        this.renderUI();
        Notify({
          message: "成功",
          background: "#34A2DA",
          color: "#fff",
          duration: 1500
        });
      });
    },
    deleteTodo(id) {
      instance.post("/api/todo/del", { id }).then(res => {
        if (res.data.status == 200) {
          this.renderUI();
          Notify({
            message: "删除成功",
            background: "#34A2DA",
            color: "#fff",
            duration: 1500
          });
        } else {
          console.log("失败");
        }
      });
    },
    editTodo(id) {
      this.$router.push({
        path: "/add",
        query: { id }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.content {
  padding: 0.05rem 0.1rem;
  height: 100%;
  margin: 0.44rem 0 0.48rem 0;
  overflow: hidden;
}
.remind {
  line-height: 0.4rem;
  margin-left: 0.38rem;
}
.van-checkbox {
  padding: 0.05rem 0.1rem;
  font-size: 0.14rem;
}
.van-checkbox__icon--disabled .van-icon {
  background-color: #1989fa !important;
  border-color: #1989fa;
}
.van-checkbox__label--disabled {
  color: #323233;
}
.list {
  background: #fff;
  width: 100%;
  height: 1rem;
  border-radius: 0.04rem;
  margin-bottom: 0.08rem;
  padding: 0.16rem;
  box-shadow: 0.01rem 0.01rem 0.02rem #b8c2f0;
  .van-checkbox {
    margin-bottom: 0.1rem;
    // font-size:.12rem;
    font-weight: 600;
  }
  .van-tag {
    margin: 0 0.1rem;
    padding: 0.01rem 0.03rem;
    font-size: 0.11rem;
  }
  span {
    font-size: 0.14rem;
  }
}
</style>
