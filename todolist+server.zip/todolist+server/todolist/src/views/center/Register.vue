<template>
  <div class="center-content">
    <h2>ToDoList</h2>
    <van-form @submit="onRegister">
      <van-field
        v-model="username"
        name="username"
        label="用户名"
        placeholder="用户名"
        maxlength="10"
        :rules="[{ required: true, message: '请填写用户名' }]"
      />
      <van-field
        v-model="password"
        type="password"
        name="password"
        label="密码"
        placeholder="密码"
        maxlength="16"
        :rules="[{ required: true, message: '请填写密码' }]"
      />
      <van-field
        v-model="message"
        rows="2"
        autosize
        label="个签"
        name="message"
        type="textarea"
        maxlength="50"
        placeholder="编辑个签，展示我的独特态度"
        show-word-limit
      />
      <div style="margin: 16px;">
        <van-button round block type="info" native-type="submit">注 册</van-button>
      </div>
    </van-form>
    <router-link to="todolist" tag="span">返回首页</router-link>
    <router-link to="login" class="right" tag="span">已有账户</router-link>
  </div>
</template>

<script>
import Vue from "vue";
import { Notify } from "vant";
import { mapMutations } from "vuex";
import { instance } from "@/utils/http";

Vue.use(Notify);

export default {
  data() {
    return {
      username: "",
      password: "",
      message: ""
    };
  },
  methods: {
    ...mapMutations("tabbar", ["tabbarhide", "tabbarshow"]),
    ...mapMutations("navbar", ["navbarhide", "navbarshow"]),
    onRegister(values) {
      
      // 发送请求到后端
      instance.post("/api/user/reg", values).then(res => {
        // 判断是否注册成功
        if (res.data.status === 200) {
          this.$router.push("/center");
          Notify({
            message: '注册成功，已自动登录',
            background: "#34A2DA",
            color: "#fff",
            duration: 1500
          });
        }else{
          Notify({ type: 'danger', message: '用户已存在！' });
        }
      });
    }
  },
  mounted() {
    this.tabbarhide();
    this.navbarhide();
  },
  destroyed() {
    this.tabbarshow();
    this.navbarshow();
  }
};
</script>

<style lang="scss" scoped>
.center-content {
  margin: 0.7rem 0 0.3rem 0;
  h2 {
    margin-bottom: 0.5rem;
    display: block;
    text-align: center;
    font-size: 0.26rem;
    color: #34a2da;
  }
  .van-cell {
    margin-bottom: 0.1rem;
    font-size: 0.14rem;
    line-height: 0.44rem;
    width: 100%;

  }    
  button {
    font-size: 0.16rem;
    height: 0.42rem;
  }
  span {
    margin: 0 0.2rem;
  }
  .right {
    float: right;
  }
}
</style>
<style lang="scss">
    .van-cell .van-field__label {
      width: 0.8rem !important;
    }
</style>