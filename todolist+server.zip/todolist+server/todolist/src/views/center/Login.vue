<template>
  <div class="center-content">
    <h2>ToDoList</h2>
    <van-form @submit="onLogin">
      <van-field
        v-model="username"
        name="username"
        label="用户名"
        placeholder="用户名"
        maxlength="10"
        :rules="[{ required: true, message: '请填写用户名' }]"
      />
      <van-field
        v-model="password"
        type="password"
        name="password"
        label="密码"
        placeholder="密码"
        maxlength="16"
        :rules="[{ required: true, message: '请填写密码' }]"
      />
      <div style="margin: 16px;">
        <van-button round block type="info" native-type="submit">登 录</van-button>
      </div>
    </van-form>
    <router-link to="todolist" tag="span">返回首页</router-link>
    <router-link to="register" class="right" tag="span">注册账户</router-link>
  </div>
</template>

<script>
import Vue from "vue";
import { instance, instance2 } from "@/utils/http";
import { mapMutations } from "vuex";
import { Field, Notify } from "vant";

Vue.use(Field).use(Notify);
export default {
  data() {
    return {
      username: "",
      password: "",
    };
  },
  methods: {
    ...mapMutations("tabbar", ["tabbarhide", "tabbarshow"]),
    ...mapMutations("navbar", ["navbarhide", "navbarshow"]),

    onLogin(values) {
      // 发送请求到后端
      instance.post("/api/user/log", values).then(res => {
        let [data] = res.data.data;
        // 判断是否存在用户名
        if (res.data.status == 200) {
          if (
            data.username == values.username &&
            data.password == values.password
          ) {
            // 将userid保存到本地存储里面去
            localStorage.setItem("todolistid", data._id);
            // 跳转到个人中心
            this.$router.replace("/center");

            Notify({
              message: "登录成功",
              background: "#34A2DA",
              color: "#fff",
              duration: 1500
            });
          } else if (data.password != values.password) {
            Notify({ type: "danger", message: "密码错误！" });
          }
        } else {
          Notify({ type: "danger", message: "用户不存在！" });
        }
      });
    }
  },
  mounted() {
    this.tabbarhide();
    this.navbarhide();
  },
  destroyed() {
    this.tabbarshow();
    this.navbarshow();
  }
};
</script>

<style lang="scss" scoped>
.center-content {
  margin: 1rem 0 0.48rem 0;
  h2 {
    margin-bottom: 0.5rem;
    display: block;
    text-align: center;
    font-size: 0.26rem;
    color: #34a2da;
  }
  .van-cell {
    margin-bottom: 0.1rem;
    font-size: 0.14rem;
    // height: .44rem;
    line-height: 0.44rem;
    width: 100%;
  }
  button {
    font-size: 0.16rem;
    height: 0.42rem;
  }
  span {
    margin: 0 0.2rem;
  }
  .right {
    float: right;
  }
}
</style>