<template>
  <div>
    <van-card
      :desc="message"
      :title="username"
      class="goods-card"
      thumb="https://img.yzcdn.cn/vant/cat.jpeg"
      centered
    />
    <van-cell title="主题" icon="brush-o" is-link />
    <van-cell title="字体" icon="bulb-o" is-link />
    <van-cell title="评分/建议" icon="chat-o" is-link />
    <van-cell title="推荐给好友" icon="user-o" is-link />
    <van-cell title="公告板" icon="bullhorn-o" value="暂无" is-link />
    <van-button type="default" @click="signOut" round block>退出登录</van-button>
  </div>
</template>

<script>
import Vue from "vue";
import { instance } from "@/utils/http";

import { Cell, CellGroup, Card, Button, Notify } from "vant";
// import { mapMutations } from "vuex";

Vue.use(Cell)
  .use(CellGroup)
  .use(Card)
  .use(Button)
  .use(Notify);
export default {
  data(){
    return {
      username:"",
      message:""
    }
  },
  created() {
    // 获取本地存储的id
    let userid = {'userid':localStorage.getItem("todolistid")};
    // 携带本地存储的id发送到后端
    instance.post("/api/user/cen", userid).then(res => {
      if(res.data.msg=="success"){
        let [datas] = res.data.data;
        this.username=datas.username;
        this.message=datas.message?datas.message:"暂无签名";
      }else{
      this.$router.replace("/login");
      }
    });
  },
  methods: {
    signOut() {
      // 删除用来检测是否登录状态的本地存储
      localStorage.removeItem("todolistid");
      this.$router.replace("/login");
      Notify({
        message: "退出登录成功",
        background: "#34A2DA",
        color: "#fff",
        duration: 1500
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.van-card {
  padding: 0.74rem 0.2rem 0.3rem 0.16rem;
  font-size: 0.2rem;
  .van-card__thumb {
    width: 0.92rem;
    height: 0.88rem;
    margin: 0 0.2rem;
    .van-image__img {
      display: block;
      border-radius: 20px !important;
    }
  }
  .van-card__title {
    max-height: 0.5rem;
    font-weight: 600;
    line-height: 0.4rem;
  }
  .van-card__desc {
    max-height: 0.3rem;
    font-size: 0.15rem;
    line-height: 0.2rem;
  }
}
.van-cell {
  padding: 0.1rem 0.16rem;
  font-size: 0.15rem;
  line-height: 0.24rem;
  color: #34a2da;
  .van-cell__left-icon {
    margin-right: 0.08rem;
    height: 0.24rem;
    font-size: 0.18rem;
    line-height: 0.24rem;
  }
  .van-cell__right-icon {
    margin-left: 5px;
    color: #34a2da;
  }
}
.van-button--normal {
  font-size: 0.15rem;
  margin-top: 0.06rem;
  color: #34a2da;
}
</style>