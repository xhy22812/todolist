<template>
  <div class="type-content">
    <van-grid :column-num="2">
      <van-grid-item
        v-for="(item,index) in type"
        :key="index"
        :text="item"
        :to="{
                    name:'detail',
                    params:{id:index+1}
                }"
      />
    </van-grid>
  </div>
</template>

<script>
import Vue from "vue";
import { Grid, GridItem } from "vant";

Vue.use(Grid);
Vue.use(GridItem);
export default {
  data() {
    return {
      type: [
        "个人备忘",
        "工作任务",
        "学习安排",
        "锻炼计划",
        "心愿清单",
        "购物清单",
        "其他"
      ]
    };
  }
};
</script>

<style lang="scss">
.type-content {
  height: 100%;
  margin-top: 0.44rem;
  overflow: hidden;
  padding: 0.1rem;
  .van-grid-item {
    height: 1.1rem;
    padding: 0.05rem;
    .van-grid-item__content {
      background: #fff;
      margin: auto;
      width: 100%;
      height: 1rem;
      border-radius: 0.04rem;
      margin-bottom: 0.08rem;
      padding: 0.16rem;
      box-shadow: 0.01rem 0.01rem 0.02rem #b8c2f0;
      .van-grid-item__text {
        font-size: 0.18rem;
      }
    }
  }
}
</style>