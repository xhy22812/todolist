<template>
  <div>
    <van-nav-bar title="编辑待办事项" left-arrow @click-left="onClickLeft" />
    <van-form @submit="onSubmit">
      <van-field v-model="title" name="title" label="事项标题" placeholder="事项标题" />
      <van-field name="radio" label="事项类型">
        <template #input>
          <van-radio-group v-model="radio" direction="horizontal">
            <van-radio name="1">个人备忘</van-radio>
            <van-radio name="2">工作任务</van-radio>
            <van-radio name="3">学习安排</van-radio>
            <van-radio name="4">锻炼计划</van-radio>
            <van-radio name="5">心愿清单</van-radio>
            <van-radio name="6">购物清单</van-radio>
            <van-radio name="7">其他</van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <van-field name="rate" label="事项等级" :rules="[{ required: true, message: '请选择等级' }]">
        <template #input>
          <van-rate v-model="rate" @change="onChange" />
        </template>
      </van-field>

      <van-field
        v-model="message"
        name="message"
        rows="2"
        autosize
        label="事项详情"
        type="textarea"
        maxlength="50"
        placeholder="详情描述"
        show-word-limit
      />
      <van-field
        readonly
        clickable
        name="starttime"
        :value="startvalue"
        label="开始时间"
        placeholder="点击选择时间"
        @click="startshow = true"
      />
      <van-popup v-model="startshow" position="bottom">
        <van-datetime-picker
          v-model="currentDate"
          type="datetime"
          :min-date="minDate"
          :max-date="maxDate"
          @confirm="onConfirm1"
        />
      </van-popup>
      <van-field
        readonly
        clickable
        name="endtime"
        :value="endvalue"
        label="结束时间"
        placeholder="点击选择时间"
        @click="endshow = true"
      />
      <van-popup v-model="endshow" position="bottom">
        <van-datetime-picker
          v-model="currentDate"
          type="datetime"
          :min-date="minDate"
          :max-date="maxDate"
          @confirm="onConfirm2"
        />
      </van-popup>
      <van-field name="state" label="事项状态">
        <template #input>
          <van-checkbox v-model="state" shape="square">完成</van-checkbox>
        </template>
      </van-field>
      <div style="margin: 0.16rem;">
        <van-button plain type="info" @click="onCancel">取消</van-button>
        <van-button type="info" native-type="submit">完成</van-button>
      </div>
    </van-form>
  </div>
</template>

<script>
import Vue from "vue";
import { instance, instance2 } from "@/utils/http";
import { mapMutations } from "vuex";
import { NavBar, Form, Toast, Calendar } from "vant";

Vue.use(NavBar)
  .use(Form)
  .use(Toast)
  .use(Calendar);
export default {
  data() {
    return {
      title: "",
      radio: "1",
      rate: 0,
      date: "",
      minDate: new Date(2020, 0, 1),
      maxDate: new Date(2025, 10, 1),
      currentDate: new Date(),
      show: false,
      startvalue: "",
      endvalue: "",
      startshow: false,
      endshow: false,
      message: "",
      state: false
    };
  },
  created() {
    let id = this.$route.query.id;
    if (id) {
      instance.post("/api/todo/data", { id }).then(res => {
        let [data] = res.data.data;
        this.title = data.title;
        this.radio = data.radio;
        this.rate = data.rate;
        this.startvalue = data.starttime;
        this.endvalue = data.endtime;
        this.message = data.message;
        this.state = data.state;
      });
    }
  },
  methods: {
    ...mapMutations("tabbar", ["tabbarhide", "tabbarshow"]),
    ...mapMutations("navbar", ["navbarhide", "navbarshow"]),

    onChange(rate) {
      Toast("当前等级：" + rate);
    },
    formatDate(date) {
      return `${date.getFullYear()}.${date.getMonth() + 1}.${date.getDate()} ${
        date.getHours() < 10 ? "0" + date.getHours() : date.getHours()
      }:${
        date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes()
      }`;
    },
    onConfirm1(time) {
      this.startshow = false;
      this.startvalue = this.formatDate(time);
    },
    onConfirm2(time) {
      this.endvalue = this.formatDate(time);
      this.endshow = false;
    },
    onClickLeft() {
      this.$router.replace("/");
    },
    onSubmit(values) {
      if (this.$route.query.id) {
        let updatevalues = { ...values, id:this.$route.query.id};
        instance.post("/api/todo/update", updatevalues);
      } else {
        let userid = localStorage.getItem("todolistid");
        let submitvalues = { ...values, userid: userid };
        // 携带表单内容以及本地存储的id（即该用户id）发送请求到后端
        instance.post("/api/todo/add", submitvalues);
      }
      this.$router.push("/");
    },
    onCancel() {
      this.$router.replace("/");
    }
  },
  mounted() {
    this.tabbarhide();
    this.navbarhide();
  },
  destroyed() {
    this.tabbarshow();
    this.navbarshow();
  }
};
</script>

<style lang="scss" scoped>
.van-radio {
  height: 0.32rem;
  line-height: 0.32rem;
}
.van-button {
  width: 45%;
  margin: 0 2.5%;
  border-radius: 0.06rem;
}
</style>