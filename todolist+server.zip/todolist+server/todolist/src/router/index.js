import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [{
  path: '/todolist',
  component: () => import("@/views/Todolist")
}, {
  name:"detail",
  path: "/detail/:id",
  component: () => import("@/views/Detail"),
  props: true
}, {
  path: "/type",
  component: () => import("@/views/Type")
}, {
  path: "/center",
  component: () => import("@/views/Center")
},{
  path: "/add",
  component: () => import("@/views/Add")
}, {
  path: "/login",
  component: () => import("@/views/center/Login")
}, {
  path: "/register",
  component: () => import("@/views/center/Register")
}, {
  path: "",
  redirect: "/todolist"
}, {
  path: "/",
  redirect: "/todolist"
}]

const router = new VueRouter({
  mode: "hash", // 默认采用hash模式
  routes
})

//判断每次路由切换的时候，是否有todolistid令牌
router.beforeEach((to,from,next)=>{
  if(to.path === "/center"){
    if(localStorage.getItem("todolistid")){//说明用户已经登录了
      next()
    }else{
      next("/login") //如果用户没有登录直接跳转到登录界面进行用户登录
    }
  }else{
    next()
  }
})

export default router
