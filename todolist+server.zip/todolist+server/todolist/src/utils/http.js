import axios from "axios"

// 这个instance是针对于数据库的接口
const instance = axios.create({
  baseURL: 'http://localhost:4000', // 基本的url
})

// 针对于上线的
const instance2 = axios.create({
  baseURL: '/info'
})

// 请求之前的拦截操作
// 每次发起请求的时候，都会判断是否添加一个请求头todolistid
instance2.interceptors.request.use(
  config => {
    if (localStorage.getItem("todolistid")) { // 如果todolistid存在，则请求头上面携带todolistid给后端传输
      config.headers.todolistid = localStorage.getItem("todolistid")
    }
    return config
  }
)

// 响应之后的拦截操作
instance2.interceptors.response.use(res => {
  if (res.data.err === 0) { // 说明后端给我们前端返回的结果是正常的
    return res.data
  } else {
    return Promise.reject(res.data.msg)
  }
})

export {
  instance,
  instance2
}