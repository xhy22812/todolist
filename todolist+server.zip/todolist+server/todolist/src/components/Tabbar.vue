<template>
  <ul>
    <router-link v-for="nav in navlist" :key="nav.id" :to="nav.path" tag="li" active-class="active">
      <van-icon :name="nav.icon" size="0.34rem" />
    </router-link>
  </ul>
</template>

<script>
import Vue from "vue";
import { Tabbar, TabbarItem, Icon } from "vant";

Vue.use(Tabbar)
  .use(TabbarItem)
  .use(Icon);
export default {
  data() {
    return {
      navlist: [
        { id: 1, path: "/todolist", icon: "todo-list" },
        { id: 2, path: "/type", icon: "more" },
        { id: 3, path: "/center", icon: "friends" }
      ]
    };
  }
};
</script>

<style lang="scss" scoped>
.active {
  color: #34a2da;
}

ul {
  position: fixed;
  left: 0px;
  bottom: 0px;
  width: 100%;
  height: 0.48rem;
  background: #fff;
  z-index: 10;
  display: flex;
  li {
    flex: 1;
    padding-top: 0.08rem;
    text-align: center;
    color: #c3c3c3;
  }
}
</style>