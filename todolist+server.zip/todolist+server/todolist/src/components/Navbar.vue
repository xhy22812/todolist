<template>
  <van-nav-bar title="ToDoList" fixed height=".4rem">
    <template #right>
      <van-icon name="add-o" size="0.2rem" @click="add" />
    </template>
  </van-nav-bar>
</template>

<script>
import Vue from "vue";
import { NavBar } from "vant";

Vue.use(NavBar);

export default {
  methods: {
    add() {
      if (localStorage.getItem("todolistid")) {
        this.$router.replace("/add");
      }else{
        this.$router.replace("/login");
      }
    }
  }
};
</script>

<style lang="scss">
.van-nav-bar {
  height: 0.44rem !important;
  line-height: 0.44rem !important;
}
.van-nav-bar .van-nav-bar__title {
  color: #34a2da;
  font-size: 0.18rem !important;
}
</style>